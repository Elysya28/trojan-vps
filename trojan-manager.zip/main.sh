#!/bin/bash
#================================================================================================
# SKRIP MANAJEMEN VPN TROJAN (Versi Final Stabil)
# Perintah akses: menu
# Dibuat Oleh A2OS
#================================================================================================

# --- PERBAIKAN PATH DEFINITIF ---
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do 
  DIR="$( cd -P "$( dirname "$SOURCE" )" &> /dev/null && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_REAL_DIR="$( cd -P "$( dirname "$SOURCE" )" &> /dev/null && pwd )"
source "$SCRIPT_REAL_DIR/config.sh"

add_user() {
    clear
    echo -e "${GREEN}--- Menambah Pengguna Baru ---${NC}"
    read -p "Password: " password
    read -p "Masa aktif (hari): " duration

    if [[ -z "$password" ]] || ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"
        return
    fi
    local exp_date=$(date -d "+$duration days" +"%Y-%m-%d")
    
    echo "$password|$exp_date" >> "$USER_DB"
    regenerate_config
    
    local domain=$(cat "$DOMAIN_FILE")

    echo -e "${GREEN}✓ Pengguna berhasil ditambahkan!${NC}"
    echo "  Masa aktif hingga: $exp_date"
    echo ""
    echo -e "${YELLOW}--- Salin Konfigurasi YAML (untuk Clash) di Bawah ---${NC}"
    echo -e "${GREEN}------------------------------------------------------${NC}"

    cat << EOF
- name: ${password}
  type: trojan
  server: ${domain}
  port: 443
  password: ${password}
  skip-cert-verify: true
  network: ws
  sni: ${domain}
  udp: true
  ws-opts:
    path: /trojan-ws
    headers:
      Host: ${domain}
EOF
    echo -e "${GREEN}------------------------------------------------------${NC}"
}

delete_user() {
    clear
    echo -e "${GREEN}--- Menghapus Pengguna ---${NC}"
    if [ ! -s "$USER_DB" ]; then
        echo -e "${RED}Tidak ada pengguna.${NC}"
        return
    fi
    mapfile -t users < "$USER_DB"
    i=1
    for user in "${users[@]}"; do
        echo "$i. $(echo "$user"|cut -d'|' -f1)"
        ((i++))
    done
    read -p "Pilih nomor pengguna: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"
        return
    fi
    sed -i "${user_num}d" "$USER_DB"
    regenerate_config
    echo -e "${GREEN}Pengguna berhasil dihapus.${NC}"
}

renew_user() {
    clear
    echo -e "${GREEN}--- Perbarui Masa Aktif ---${NC}"
    if [ ! -s "$USER_DB" ]; then
        echo -e "${RED}Tidak ada pengguna.${NC}"
        return
    fi
    mapfile -t users < "$USER_DB"
    i=1
    for user in "${users[@]}"; do
        echo "$i. $(echo "$user"|cut -d'|' -f1) (Hingga: $(echo "$user"|cut -d'|' -f2))"
        ((i++))
    done
    read -p "Pilih pengguna: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"
        return
    fi
    read -p "Tambahan masa aktif (hari): " duration
    if ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"
        return
    fi
    old_line=$(sed -n "${user_num}p" "$USER_DB")
    password=$(echo "$old_line"|cut -d'|' -f1)
    old_exp_date=$(echo "$old_line"|cut -d'|' -f2)
    new_exp_date=$(date -d "$old_exp_date + $duration days" +"%Y-%m-%d")
    sed -i "${user_num}s/.*/$password|$new_exp_date/" "$USER_DB"
    regenerate_config
    echo -e "${GREEN}Masa aktif diperbarui hingga: $new_exp_date${NC}"
}

list_users() {
    while true; do
        clear
        echo -e "${GREEN}--- Daftar Pengguna ---${NC}"
        auto_clean_expired_users
        if [ ! -s "$USER_DB" ]; then
            echo "Belum ada pengguna."
            read -n 1 -s -r -p "Tekan apa saja untuk kembali..."
            return
        fi

        mapfile -t users < "$USER_DB"
        
        i=1
        printf "%-4s %-20s %-15s %-15s\n" "No." "Password" "Hingga" "Sisa"
        echo "----------------------------------------------------------"
        for user_line in "${users[@]}"; do
            password=$(echo "$user_line"|cut -d'|' -f1)
            exp_date=$(echo "$user_line"|cut -d'|' -f2)
            sisa_hari=$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 ))
            printf "%-4s %-20s %-15s %-15s\n" "$i." "$password" "$exp_date" "$sisa_hari hari"
            ((i++))
        done
        echo "----------------------------------------------------------"
        echo ""
        
        read -p "Pilih nomor untuk melihat config YAML (Enter untuk kembali): " user_num

        if [ -z "$user_num" ]; then
            return
        fi

        if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid!${NC}"
            sleep 2
            continue
        fi

        selected_line="${users[$((user_num-1))]}"
        password=$(echo "$selected_line" | cut -d'|' -f1)
        domain=$(cat "$DOMAIN_FILE")

        clear
        echo -e "Config YAML untuk pengguna: ${YELLOW}${password}${NC}"
        echo -e "${GREEN}------------------------------------------------------${NC}"
        cat << EOF
- name: ${password}
  type: trojan
  server: ${domain}
  port: 443
  password: ${password}
  skip-cert-verify: true
  network: ws
  sni: ${domain}
  udp: true
  ws-opts:
    path: /trojan-ws
    headers:
      Host: ${domain}
EOF
        echo -e "${GREEN}------------------------------------------------------${NC}"
        echo ""
        read -n 1 -s -r -p "Tekan tombol apa saja untuk kembali ke daftar pengguna..."
    done
}

auto_clean_expired_users() {
    if [ ! -f "$USER_DB" ]; then
        return
    fi
    today_epoch=$(date +%s)
    temp_db=$(mktemp)
    changed=false
    while IFS= read -r line; do
        exp_epoch=$(date -d "$(echo "$line"|cut -d'|' -f2)" +%s)
        if [ "$exp_epoch" -ge "$today_epoch" ]; then
            echo "$line" >> "$temp_db"
        else
            changed=true
        fi
    done < "$USER_DB"
    mv "$temp_db" "$USER_DB"
    if [ "$changed" = true ]; then
        echo "Membersihkan pengguna..."
        regenerate_config
    fi
}

# --- Fungsi Instalasi ---
run_installation() {
    clear
    echo -e "${GREEN}--- Memulai Instalasi ---${NC}"
    read -p "Masukkan domain Anda: " DOMAIN
    if [ -z "$DOMAIN" ]; then
        echo "${RED}Domain kosong!${NC}"
        exit 1
    fi
    mkdir -p /etc/xray /usr/local/etc/xray "$INSTALL_DIR"
    echo "$DOMAIN" > "$DOMAIN_FILE"
    echo "Menyalin skrip ke $INSTALL_DIR..."
    cp "$SCRIPT_REAL_DIR"/*.sh "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR"/*.sh
    ln -sf "$INSTALL_DIR/main.sh" /usr/local/bin/menu
    echo "=> Menginstal dependensi..."
    apt-get update -y
    apt-get --reinstall --fix-missing install -y sudo dpkg psmisc socat jq ruby wondershaper python2 tmux nmap bzip2 gzip coreutils wget curl screen rsyslog iftop htop net-tools zip unzip vim nano sed gnupg gnupg1 bc apt-transport-https build-essential gcc g++ automake make autoconf perl m4 dos2unix dropbear libreadline-dev zlib1g-dev libssl-dev dirmngr libxml-parser-perl neofetch git lsof iptables iptables-persistent openssl easy-rsa fail2ban vnstat libsqlite3-dev cron bash-completion ntpdate xz-utils gnupg2 dnsutils lsb-release chrony nginx
    gem install lolcat
    echo "=> Menginstal rclone..."
    curl https://rclone.org/install.sh | bash
    echo "=> Mengatur IPv6 & Waktu..."
    echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
    sed -i '/net.ipv6.conf.all.disable_ipv6/d' /etc/sysctl.conf
    echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
    sysctl -p
    timedatectl set-timezone Asia/Jakarta
    echo "=> Menginstal Xray-core..."
    curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh | bash
    echo "=> Membuat sertifikat SSL..."
    systemctl stop nginx
    curl https://get.acme.sh | sh
    ~/.acme.sh/acme.sh --set-default-ca --server letsencrypt
    ~/.acme.sh/acme.sh --issue -d "$DOMAIN" --standalone -k ec-256 --force
    ~/.acme.sh/acme.sh --install-cert -d "$DOMAIN" --key-file "$KEY_FILE" --cert-file "$CERT_FILE" --ecc
    if [[ ! -f "$CERT_FILE" || ! -f "$KEY_FILE" ]]; then
        echo -e "${RED}Gagal membuat SSL!${NC}"
        exit 1
    fi
    echo "=> Konfigurasi akhir..."
    regenerate_config
    (crontab -l 2>/dev/null; echo "0 3 * * * $MAIN_SCRIPT_PATH --autoclean")|crontab -
    # add_user
    echo -e "${GREEN}Instalasi selesai! Jalankan 'menu' untuk membuka panel.${NC}"
    
    echo "=> Membersihkan direktori kerja awal..."
    rm -rf "$SCRIPT_REAL_DIR"
}

# --- Fungsi Helium ---
install_update_helium() {
    clear
    echo -e "${GREEN}--- Instalasi/Update Helium ---${NC}"
    if rm -rf /usr/local/sbin/helium && wget -q -O /usr/local/sbin/helium https://raw.githubusercontent.com/abidarwish/helium/main/helium.sh && chmod +x /usr/local/sbin/helium; then
        echo -e "${GREEN}Helium terinstal. Menjalankan...${NC}"
        sleep 2
        helium
    else
        echo -e "${RED}Gagal instal Helium.${NC}"
    fi
}

run_helium() {
    clear
    if command -v helium &> /dev/null; then
        echo -e "${GREEN}Menjalankan Helium...${NC}"
        helium
    else
        echo -e "${RED}Helium tidak ditemukan.${NC}"
    fi
}

menu_helium() {
    clear
    while true; do
        echo -e "${GREEN}--- Menu Helium ---${NC}"
        echo "1. Install/Update & Jalankan"
        echo "2. Jalankan (jika terinstal)"
        echo "3. Kembali"
        echo ""
        read -p "Pilih [1-3]: " choice
        case $choice in
            1) install_update_helium; break;;
            2) run_helium; break;;
            3) break;;
            *) echo -e "${RED}Pilihan salah!${NC}"; sleep 1; clear;;
        esac
    done
}

# --- Fungsi Tampilan & Menu ---
display_info_panel() {
    os_info=$(lsb_release -ds)
    cpu_cores=$(nproc)
    ram_info=$(free -m|awk 'NR==2{printf "%.2f/%.2f GB", $3/1024, $2/1024}')
    uptime_info=$(uptime -p)
    ip_info=$(curl -s 'http://ip-api.com/json/')
    vps_ip=$(echo "$ip_info"|jq -r '.query')
    vps_city=$(echo "$ip_info"|jq -r '.city')
    vps_domain=$(cat "$DOMAIN_FILE")
    total_users=0
    if [ -f "$USER_DB" ]; then
        total_users=$(wc -l <"$USER_DB"|xargs)
    fi
    if systemctl is-active --quiet xray; then
        xray_status="${GREEN}ON${NC}"
    else
        xray_status="${RED}OFF${NC}"
    fi
    if systemctl is-active --quiet nginx; then
        nginx_status="${GREEN}ON${NC}"
    else
        nginx_status="${RED}OFF${NC}"
    fi
    current_date=$(date +"%A, %d %B %Y")
    current_time=$(date +"%T WIB")
    usage_today=$(vnstat -d | grep "$(date +"%Y-%m-%d")" | awk '{print $8, $9}')
    [ -z "$usage_today" ] && usage_today="Data Belum Tersedia"
    
    usage_yesterday=$(vnstat -d | grep "$(date -d "yesterday" +"%Y-%m-%d")" | awk '{print $8, $9}')
    [ -z "$usage_yesterday" ] && usage_yesterday="Data Belum Tersedia"
    
	usage_this_month=$(vnstat -m | grep "$(date +"%Y-%m")" | awk '{print $8, $9}')
    [ -z "$usage_this_month" ] && usage_this_month="Data Belum Tersedia"

    clear
    echo -e "${GREEN}=============[ PANEL MANAJEMEN A2OS ]==============${NC}"
    printf "%-12s: %s\n" "OS" "$os_info"
    printf "%-12s: %s\n" "CPU Core" "$cpu_cores Core"
    printf "%-12s: %s\n" "RAM" "$ram_info"
    printf "%-12s: %s\n" "Domain" "$vps_domain"
    printf "%-12s: %s\n" "IP VPS" "$vps_ip"
    printf "%-12s: %s\n" "City" "$vps_city"
    printf "%-12s: %s\n" "Uptime" "$uptime_info"
    printf "%-12s: %s\n" "Date" "$current_date"
    printf "%-12s: %s\n" "Time" "$current_time"
    echo -e "${GREEN}===================================================${NC}"
    status_line="Xray: [${xray_status}] | Nginx: [${nginx_status}]"
    clean_line_status=$(echo -e "$status_line" | sed 's/\x1b\[[0-9;]*m//g')
    padding_status=$(((51 - ${#clean_line_status}) / 2))
    printf "%*s" $padding_status ""
    echo -e "$status_line"
    echo -e "${GREEN}================[ PENGGUNAAN DATA ]================${NC}"
    printf "%-12s: %s\n" "Hari Ini" "$usage_today"
    printf "%-12s: %s\n" "Kemarin" "$usage_yesterday"
    printf "%-12s: %s\n" "Bulan Ini" "$usage_this_month"
    echo -e "${GREEN}==================[ TOTAL AKUN ]===================${NC}"
	echo ""
    akun_line="Total Akun: ${total_users}"
    padding_akun=$(((51 - ${#akun_line}) / 2))
    printf "%*s%s\n" $padding_akun "" "$akun_line"
	echo ""
}
main_menu() {
    while true; do
        display_info_panel
        
		echo -e "${GREEN}==================[ MENU UTAMA ]===================${NC}"
        printf "│ %-48s │\n" ""
        printf "│ %-48s │\n" "    1. Buat Akun"
        printf "│ %-48s │\n" "    2. Hapus Akun"
        printf "│ %-48s │\n" "    3. Perbarui Masa Aktif"
        printf "│ %-48s │\n" "    4. List Akun"
        printf "│ %-48s │\n" "    5. Backup Data"
        printf "│ %-48s │\n" "    6. Restore Data"
        printf "│ %-48s │\n" "    7. Menu Helium"
        printf "│ %-48s │\n" "    8. Keluar"
        printf "│ %-48s │\n" ""
	    echo -e "${GREEN}=============[ PANEL MANAJEMEN A2OS ]==============${NC}"
		echo ""
		echo -e "${GREEN}===================================================${NC}"
		printf "Pilih opsi [1-8]: "
		read choice # <-- 'read' sekarang berada SEBELUM garis kedua
		echo -e "${GREEN}===================================================${NC}"
        
        case $choice in
            1) add_user;;
            2) delete_user;;
            3) renew_user;;
            4) list_users;;
            5) "$INSTALL_DIR/backup.sh";;
            6) "$INSTALL_DIR/restore.sh";;
            7) menu_helium;;
            8) exit 0;;
            *) echo -e "${RED}Pilihan salah!${NC}";;
        esac
        echo ""
        read -n 1 -s -r -p "Tekan apa saja untuk lanjut..."
    done
}

# --- Logika Utama Skrip ---
check_root
if [[ "$1" == "--autoclean" ]]; then
    auto_clean_expired_users
    exit 0
fi
if [ ! -f "$CONFIG_FILE" ]; then
    run_installation
fi
main_menu
