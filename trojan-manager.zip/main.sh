#!/bin/bash

#================================================================================================
# SKRIP MANAJEMEN UTAMA (BASIS DARI tes.sh)
# Perintah akses: menu
# Fitur tambahan: Menu Helium
#================================================================================================

# Sumberkan file konfigurasi bersama.
source "$(dirname "$0")/config.sh"

# --- Fungsi Manajemen Pengguna ---
add_user() {
    clear
    echo -e "${GREEN}--- Menambah Pengguna Trojan Baru ---${NC}"
    read -p "Masukkan password untuk pengguna baru: " password
    read -p "Masukkan masa aktif (dalam hari, contoh: 30): " duration
    if [[ -z "$password" ]] || ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"; return
    fi
    local exp_date
    exp_date=$(date -d "+$duration days" +"%Y-%m-%d")
    echo "$password|$exp_date" >> "$USER_DB"
    regenerate_config
    echo -e "${GREEN}Pengguna berhasil ditambahkan!${NC}"
    echo "Password: $password | Berlaku hingga: $exp_date"
}

delete_user() {
    clear
    echo -e "${GREEN}--- Menghapus Pengguna Trojan ---${NC}"
    if [ ! -s "$USER_DB" ]; then echo -e "${RED}Tidak ada pengguna.${NC}"; return; fi
    mapfile -t users < "$USER_DB"
    local i=1
    for user in "${users[@]}"; do
        echo "$i. $(echo "$user" | cut -d'|' -f1)"
        ((i++))
    done
    read -p "Pilih nomor pengguna yang akan dihapus: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"; return
    fi
    sed -i "${user_num}d" "$USER_DB"
    regenerate_config
    echo -e "${GREEN}Pengguna berhasil dihapus.${NC}"
}

renew_user() {
    clear
    echo -e "${GREEN}--- Memperbarui Masa Aktif ---${NC}"
    if [ ! -s "$USER_DB" ]; then echo -e "${RED}Tidak ada pengguna.${NC}"; return; fi
    mapfile -t users < "$USER_DB"
    local i=1
    for user in "${users[@]}"; do
        echo "$i. $(echo "$user" | cut -d'|' -f1) (Berlaku hingga: $(echo "$user" | cut -d'|' -f2))"
        ((i++))
    done
    read -p "Pilih nomor pengguna: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"; return
    fi
    read -p "Tambahan masa aktif (hari): " duration
    if ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"; return
    fi
    local old_line
    old_line=$(sed -n "${user_num}p" "$USER_DB")
    local password
    password=$(echo "$old_line" | cut -d'|' -f1)
    local old_exp_date
    old_exp_date=$(echo "$old_line" | cut -d'|' -f2)
    local new_exp_date
    new_exp_date=$(date -d "$old_exp_date + $duration days" +"%Y-%m-%d")
    sed -i "${user_num}s/.*/$password|$new_exp_date/" "$USER_DB"
    regenerate_config
    echo -e "${GREEN}Masa aktif diperbarui! Berlaku hingga: $new_exp_date${NC}"
}

list_users() {
    clear
    echo -e "${GREEN}--- Daftar Pengguna Trojan ---${NC}"
    auto_clean_expired_users
    if [ ! -s "$USER_DB" ]; then echo "Belum ada pengguna."; return; fi
    local i=1
    printf "%-4s %-20s %-15s %-15s\n" "No." "Password" "Berlaku Hingga" "Sisa Hari"
    echo "----------------------------------------------------------------"
    while IFS= read -r line; do
        local password exp_date sisa_hari
        password=$(echo "$line" | cut -d'|' -f1)
        exp_date=$(echo "$line" | cut -d'|' -f2)
        sisa_hari=$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 ))
        printf "%-4s %-20s %-15s %-15s\n" "$i." "$password" "$exp_date" "$sisa_hari hari"
        ((i++))
    done < "$USER_DB"
}

auto_clean_expired_users() {
    if [ ! -f "$USER_DB" ]; then return; fi
    local today_epoch temp_db changed
    today_epoch=$(date +%s)
    temp_db=$(mktemp)
    changed=false
    while IFS= read -r line; do
        local exp_epoch
        exp_epoch=$(date -d "$(echo "$line" | cut -d'|' -f2)" +%s)
        if [ "$exp_epoch" -ge "$today_epoch" ]; then
            echo "$line" >> "$temp_db"
        else
            changed=true
        fi
    done < "$USER_DB"
    mv "$temp_db" "$USER_DB"
    if [ "$changed" = true ]; then
        echo "Membersihkan pengguna kedaluwarsa..."
        regenerate_config
    fi
}

# --- Fungsi Instalasi ---
run_installation() {
    clear
    echo -e "${GREEN}--- Memulai Instalasi Awal Server Trojan ---${NC}"
    read -p "Masukkan nama domain Anda: " DOMAIN
    if [ -z "$DOMAIN" ]; then echo "${RED}Domain tidak boleh kosong!${NC}"; exit 1; fi
    
    mkdir -p /etc/xray /usr/local/etc/xray "$INSTALL_DIR"
    echo "$DOMAIN" > "$DOMAIN_FILE"

    echo "Menyalin skrip ke $INSTALL_DIR..."
    cp "$SCRIPT_DIR/main.sh" "$INSTALL_DIR/"
    cp "$SCRIPT_DIR/backup.sh" "$INSTALL_DIR/"
    cp "$SCRIPT_DIR/restore.sh" "$INSTALL_DIR/"
    cp "$SCRIPT_DIR/config.sh" "$INSTALL_DIR/"
    chmod +x "${INSTALL_DIR}/main.sh" "${INSTALL_DIR}/backup.sh" "${INSTALL_DIR}/restore.sh"

    ln -sf "${INSTALL_DIR}/main.sh" /usr/local/bin/menu

    echo "=> Menginstal semua dependensi yang diminta..."
    apt-get update -y
    apt-get --reinstall --fix-missing install -y \
        sudo dpkg psmisc socat jq ruby wondershaper python2 tmux nmap bzip2 gzip coreutils \
        wget curl screen rsyslog iftop htop net-tools zip unzip vim nano sed gnupg gnupg1 bc \
        apt-transport-https build-essential gcc g++ automake make autoconf perl m4 dos2unix \
        dropbear libreadline-dev zlib1g-dev libssl-dev dirmngr libxml-parser-perl neofetch \
        git lsof iptables iptables-persistent openssl easy-rsa fail2ban vnstat libsqlite3-dev \
        cron bash-completion ntpdate xz-utils gnupg2 dnsutils lsb-release chrony nginx rclone

    gem install lolcat

    echo "=> Menonaktifkan IPv6..."
    echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
    if [ ! -f /etc/rc.local ]; then
        echo -e "#!/bin/bash\nexit 0" > /etc/rc.local
        chmod +x /etc/rc.local
    fi
    sed -i '$ i\echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6' /etc/rc.local

    apt-get upgrade -y && apt-get dist-upgrade -y
    
    echo "=> Mengatur zona waktu ke Asia/Jakarta..."
    timedatectl set-timezone Asia/Jakarta

    echo "=> Menginstal Xray-core..."
    curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh | bash

    echo "=> Membuat sertifikat SSL..."
    systemctl stop nginx
    curl https://get.acme.sh | sh
    source ~/.bashrc
    ~/.acme.sh/acme.sh --set-default-ca --server letsencrypt
    ~/.acme.sh/acme.sh --issue -d "$DOMAIN" --standalone -k ec-256 --force
    ~/.acme.sh/acme.sh --install-cert -d "$DOMAIN" --key-file "$KEY_FILE" --cert-file "$CERT_FILE" --ecc
    if [[ ! -f "$CERT_FILE" || ! -f "$KEY_FILE" ]]; then
        echo -e "${RED}Gagal membuat sertifikat SSL. Instalasi dihentikan.${NC}"; exit 1
    fi

    echo "=> Mengkonfigurasi vnstat..."
    local net_interface
    net_interface=$(ip -4 route ls | grep default | grep -Po '(?<=dev )(\S+)' | head -1)
    if [ -n "$net_interface" ]; then
        sed -i "s/^Interface .*/Interface \"$net_interface\"/" /etc/vnstat.conf
        systemctl restart vnstat
    fi
    
    echo "=> Memberi tahu pengguna tentang konfigurasi rclone..."
    echo -e "${YELLOW}LANGKAH PENTING: Jalankan 'rclone config' untuk setup remote cloud Anda.${NC}"
    
    echo "=> Membuat database & cron untuk auto-cleanup..."
    touch "$USER_DB"
    (crontab -l 2>/dev/null; echo "0 3 * * * $MAIN_SCRIPT_PATH --autoclean") | crontab -

    echo "=> Membuat pengguna pertama..."
    add_user

    echo -e "${GREEN}Instalasi awal selesai! Jalankan 'menu' untuk membuka panel manajemen.${NC}"
    sleep 3
}

# --- Fungsi Helium ---
install_update_helium() {
    clear
    echo -e "${GREEN}--- Memulai Instalasi/Update Helium ---${NC}"
    # Perintah instalasi yang Anda berikan
    if rm -rf /usr/local/sbin/helium && wget -q -O /usr/local/sbin/helium https://raw.githubusercontent.com/abidarwish/helium/main/helium.sh && chmod +x /usr/local/sbin/helium; then
        echo -e "${GREEN}Helium berhasil diinstal/diperbarui.${NC}"
        echo -e "${YELLOW}Menjalankan Helium sekarang...${NC}"
        sleep 2
        # Langsung menjalankan helium setelah instalasi
        helium
    else
        echo -e "${RED}Gagal menginstal Helium. Periksa koneksi internet atau URL skrip.${NC}"
    fi
}

run_helium() {
    clear
    if command -v helium &> /dev/null; then
        echo -e "${GREEN}Menjalankan Helium...${NC}"
        helium
    else
        echo -e "${RED}Helium tidak ditemukan.${NC}"
        echo -e "${YELLOW}Silakan instal terlebih dahulu melalui menu 'Install/Update Helium'.${NC}"
    fi
}

menu_helium() {
    clear
    while true; do
        echo -e "${GREEN}--- Menu Manajemen Helium ---${NC}"
        echo "1. Install/Update & Jalankan Helium"
        echo "2. Jalankan Helium (jika sudah terinstal)"
        echo "3. Kembali ke Menu Utama"
        echo ""
        read -p "Pilih opsi [1-3]: " choice_helium

        case $choice_helium in
            1)
                install_update_helium
                break
                ;;
            2)
                run_helium
                break
                ;;
            3)
                break
                ;;
            *)
                echo -e "${RED}Pilihan tidak valid!${NC}"
                sleep 1
                clear
                ;;
        esac
    done
}


# --- Fungsi Tampilan & Menu ---
display_info_panel() {
    local os_info cpu_cores ram_info uptime_info ip_info vps_ip vps_isp vps_city vps_domain total_users xray_status nginx_status
    os_info=$(lsb_release -ds)
    cpu_cores=$(nproc)
    ram_info=$(free -m | awk 'NR==2{printf "%.2f/%.2f GB", $3/1024, $2/1024}')
    uptime_info=$(uptime -p)
    ip_info=$(curl -s 'http://ip-api.com/json/')
    vps_ip=$(echo "$ip_info" | jq -r '.query')
    vps_isp=$(echo "$ip_info" | jq -r '.isp')
    vps_city=$(echo "$ip_info" | jq -r '.city')
    vps_domain=$(cat "$DOMAIN_FILE")
    total_users=0
    if [ -f "$USER_DB" ]; then total_users=$(wc -l < "$USER_DB" | xargs); fi
    if systemctl is-active --quiet xray; then xray_status="${GREEN}AKTIF${NC}"; else xray_status="${RED}MATI${NC}"; fi
    if systemctl is-active --quiet nginx; then nginx_status="${GREEN}AKTIF${NC}"; else nginx_status="${RED}MATI${NC}"; fi

    clear
    echo -e "${GREEN}======================[ PANEL MANAJEMEN TROJAN ]=======================${NC}"
    printf "%-12s: %-25s %-12s: %s\n" "OS" "$os_info" "CPU Core" "$cpu_cores"
    printf "%-12s: %-25s %-12s: %s\n" "RAM" "$ram_info" "Uptime" "$uptime_info"
    printf "%-12s: %-25s %-12s: %s\n" "ISP" "$vps_isp" "Kota" "$vps_city"
    printf "%-12s: %-25s %-12s: %s\n" "IP VPS" "$vps_ip" "Domain" "$vps_domain"
    echo -e "${GREEN}-----------------------------------------------------------------------${NC}"
    printf "Status Layanan -> Xray: [${xray_status}] | Nginx: [${nginx_status}]\n"
    printf "Total Akun Trojan Aktif : %s\n" "$total_users"
    echo ""
    echo "--- Detail Konfigurasi Klien (Trojan WebSocket) ---"
    printf "%-10s: %s\n" "Alamat" "$vps_domain"
    printf "%-10s: %s\n" "Port" "443"
    printf "%-10s: %s\n" "Jaringan" "ws"
    printf "%-10s: %s\n" "Path" "/trojan-ws"
    echo -e "${GREEN}=======================================================================${NC}"
}

main_menu() {
    while true; do
        display_info_panel
        echo -e "${YELLOW}Menu Manajemen Pengguna:${NC}"
        echo "1. Tambah Pengguna"
        echo "2. Hapus Pengguna"
        echo "3. Perbarui Masa Aktif"
        echo "4. Lihat Daftar Pengguna"
        echo ""
        echo -e "${YELLOW}Menu Backup & Restore:${NC}"
        echo "5. Backup Data ke Cloud"
        echo "6. Restore Data dari Cloud"
        echo ""
        echo -e "${YELLOW}Menu Alat Tambahan:${NC}"
        echo "7. Menu Helium"
        echo ""
        echo "8. Keluar"
        echo ""
        read -p "Pilih opsi [1-8]: " choice

        case $choice in
            1) add_user ;;
            2) delete_user ;;
            3) renew_user ;;
            4) list_users ;;
            5) "${INSTALL_DIR}/backup.sh" ;;
            6) "${INSTALL_DIR}/restore.sh" ;;
            7) menu_helium ;;
            8) exit 0 ;;
            *) echo -e "${RED}Pilihan tidak valid!${NC}" ;;
        esac
        echo ""
        read -n 1 -s -r -p "Tekan tombol apa saja untuk kembali ke menu..."
    done
}

# --- Logika Utama Skrip ---
check_root

if [[ "$1" == "--autoclean" ]]; then
    auto_clean_expired_users
    exit 0
fi

if [ ! -f "$CONFIG_FILE" ]; then
    run_installation
fi

main_menu