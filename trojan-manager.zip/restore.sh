#!/bin/bash

#================================================================================================
# SKRIP RESTORE DATA
#================================================================================================

# Sumberkan file konfigurasi bersama
source "$(dirname "$0")/config.sh"

# Pastikan dijalankan sebagai root
check_root

# Variabel untuk spinner
SPINNER_PID=""
# Fungsi spinner (disalin dari main.sh agar mandiri)
start_spinner() {
    local i=1
    local sp="/-\|"
    echo -n "  "
    while true; do
        printf "\b%c" "${sp:i++%${#sp}:1}"
        sleep 0.1
    done &
    SPINNER_PID=$!
    trap "kill $SPINNER_PID > /dev/null 2>&1" EXIT
}

stop_spinner() {
    if [ -n "$SPINNER_PID" ]; then
        kill "$SPINNER_PID" > /dev/null 2>&1
        wait "$SPINNER_PID" 2>/dev/null
        echo -e "\b " # Hapus spinner dan spasi
        SPINNER_PID=""
    fi
    trap - EXIT # Hapus trap
}


restore_data() {
    clear
    if ! command -v rclone &> /dev/null; then
        echo -e "${RED}rclone tidak terinstal. Fitur ini tidak tersedia.${NC}"; return
    fi
    
    # Jalankan setup jika file conf belum ada
    setup_rclone || { echo -e "${RED}Setup Rclone dibatalkan.${NC}"; return 1; }

    # Muat konfigurasi rclone
    source "$RCLONE_CONF"

    echo -e "${GREEN}--- Memulai Proses Restore ---${NC}"
    echo "Mencari file backup di $RCLONE_REMOTE:$RCLONE_PATH ..."
    
    mapfile -t backups < <(rclone lsf "$RCLONE_REMOTE:$RCLONE_PATH" | grep '\.tar\.gz$' | sort -r)
    if [ ${#backups[@]} -eq 0 ]; then
        echo -e "${RED}Tidak ditemukan file backup (.tar.gz) di remote.${NC}"; return
    Hapus  fi

    echo "Pilih file backup yang akan dipulihkan:"
    local i=1
    for backup in "${backups[@]}"; do
        echo "$i. $backup"
        i=$((i+1))
    done

    read -p "Masukkan nomor file backup: " backup_num
    if ! [[ "$backup_num" =~ ^[0-9]+$ ]] || [ "$backup_num" -lt 1 ] || [ "$backup_num" -gt ${#backups[@]} ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"; return
    fi

    local selected_backup=${backups[$((backup_num-1))]}
    local tmp_restore_path="/tmp/$selected_backup"

    echo "Mengunduh $selected_backup..."
    start_spinner
    if ! rclone copy "$RCLONE_REMOTE:$RCLONE_PATH/$selected_backup" "/tmp/" &>/dev/null; then
        stop_spinner
        echo -e "${RED}Gagal mengunduh file backup!${NC}"; return
    fi
    stop_spinner
    echo -e "${GREEN}✓ File backup berhasil diunduh.${NC}"

    echo -e "${YELLOW}PERINGATAN: Proses ini akan menimpa semua data konfigurasi xray yang ada!${NC}"
    read -p "Apakah Anda yakin ingin melanjutkan? (y/n): " confirm
    if [[ "$confirm" != "y" ]]; then
        echo "Restore dibatalkan."; rm -f "$tmp_restore_path"; return
    fi
    
    local local_bak_dir="/etc/xray.bak.$(date +%s)"
    echo "Membuat backup lokal darurat di $local_bak_dir"
    start_spinner
    mv /etc/xray "$local_bak_dir" &>/dev/null
    stop_spinner
    echo -e "${GREEN}✓ Backup darurat dibuat.${NC}"

    echo "Mengekstrak file backup..."
    start_spinner
    if ! tar -xzf "$tmp_restore_path" -C /etc &>/dev/null; then
        stop_spinner
        echo -e "${RED}Gagal mengekstrak file backup! Memulihkan dari backup darurat.${NC}"
        mv "$local_bak_dir" /etc/xray
        rm -f "$tmp_restore_path"
        return
    fi
    stop_spinner
    echo -e "${GREEN}✓ File backup diekstrak.${NC}"

    rm -f "$tmp_restore_path"
    rm -rf "$local_bak_dir"

    echo "Memperbarui konfigurasi dan me-restart layanan..."
    regenerate_config

    echo -e "${GREEN}Restore berhasil diselesaikan! Konfigurasi telah dipulihkan.${NC}"
}

# Jalankan fungsi utama
restore_data