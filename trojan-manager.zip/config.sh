#!/bin/bash

#================================================================================================
# FILE KONFIGURASI BERSAMA (Versi dengan XRay Fallbacks & WGCF yang Diperbaiki)
#================================================================================================

# --- Variabel Global & Warna ---
GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[0;33m"
NC="\033[0m"

# --- Path Direktori & File ---
# Menentukan path absolut dari direktori skrip saat ini
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Path untuk file-file penting
USER_DB="/etc/xray/user_database.txt"
CONFIG_FILE="/usr/local/etc/xray/config.json"
NGINX_CONF="/etc/nginx/conf.d/xray.conf"
CERT_FILE="/etc/xray/xray.crt"
KEY_FILE="/etc/xray/xray.key"
DOMAIN_FILE="/etc/xray/domain.txt"
RCLONE_CONF="/etc/xray/rclone.conf"
WGCF_CONFIG_FILE="/etc/wireguard/wgcf.conf" # Nama file konfigurasi WGCF yang benar

# Path instalasi skrip di sistem
INSTALL_DIR="/usr/local/bin/trojan-manager"
MAIN_SCRIPT_PATH="${INSTALL_DIR}/main.sh"

# Fungsi untuk memeriksa hak akses root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}Skrip ini harus dijalankan sebagai root${NC}"
        exit 1
    fi
}

# Fungsi untuk membuat ulang file konfigurasi Xray dan Nginx
regenerate_config() {
    local domain
    domain=$(cat "$DOMAIN_FILE")
    local clients_json=""
    if [ -s "$USER_DB" ]; then
        while IFS= read -r line; do
            local password
            password=$(echo "$line" | cut -d'|' -f1)
            clients_json+="{ \"password\": \"$password\" },"
        done < "$USER_DB"
        clients_json=${clients_json%,}
    fi

    # === KONFIGURASI XRAY BARU DENGAN FALLBACKS ===
    # XRay akan berjalan di port 443 dan menangani TLS.
    # Tambahkan routing untuk WGCF jika aktif
    local outbound_wgcf=""
    local routing_wgcf=""
    if systemctl is-active --quiet wg-quick@wgcf; then # Cek apakah WGCF aktif
        outbound_wgcf=',{ "protocol": "freedom", "tag": "direct", "settings": {} },{ "protocol": "socks", "tag": "warp", "settings": { "servers": [ { "address": "127.0.0.1", "port": 40000 } ] } }'
        routing_wgcf=',{ "type": "field", "outboundTag": "warp", "ip": ["geoip:private", "geoip:cn", "geoip:kp"] }'
    else
        outbound_wgcf=',{ "protocol": "freedom", "tag": "direct", "settings": {} }'
    fi

    cat << EOF > "$CONFIG_FILE"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "trojan",
      "settings": {
        "clients": [ $clients_json ],
        "fallbacks": [
          {
            "dest": 8080,
            "xver": 1
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {
          "certificates": [
            {
              "certificateFile": "$CERT_FILE",
              "keyFile": "$KEY_FILE"
            }
          ]
        },
        "wsSettings": {
          "path": "/trojan-ws"
        }
      }
    }
  ],
  "outbounds": [{ "protocol": "freedom" } $outbound_wgcf],
  "routing": {
    "domainStrategy": "AsIs",
    "rules": [
      {
        "type": "field",
        "ip": ["geoip:private"],
        "outboundTag": "direct"
      }
      $routing_wgcf
    ]
  }
}
EOF

    chown -R nobody:nogroup /etc/xray/

    if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
        echo "Me-restart layanan Xray dan Nginx..."
        systemctl restart xray
        systemctl restart nginx
    else
        echo -e "${YELLOW}Sertifikat SSL belum tersedia. Nginx tidak direstart.${NC}"
    fi
}

setup_rclone() {
    if [ -f "$RCLONE_CONF" ]; then return 0; fi
    clear
	echo -e "${YELLOW}===========[ PENGATURAN AWAL BACKUP/RESTORE (RCLONE) ]===========${NC}"
	echo ""
    echo "Anda akan diarahkan ke setup interaktif Rclone untuk menghubungkan akun cloud."
    read -n 1 -s -r -p "Tekan tombol apa saja untuk memulai 'rclone config'..."
    rclone config
    echo -e "\n${GREEN}Setup interaktif Rclone Selesai.${NC}"
	echo -e "${YELLOW}=================================================================${NC}"
	echo ""
    echo "Mendeteksi remote yang tersedia..."
    mapfile -t remotes < <(rclone listremotes | sed 's/://')
    local rclone_remote=""
    if [ ${#remotes[@]} -eq 0 ]; then
        echo -e "${RED}Tidak ada remote Rclone yang terdeteksi. Setup gagal.${NC}"
        return 1
    elif [ ${#remotes[@]} -eq 1 ]; then
        rclone_remote="${remotes[0]}"
        echo -e "${GREEN}Satu remote terdeteksi: ${YELLOW}$rclone_remote${GREEN}. Remote ini akan digunakan secara otomatis.${NC}"
    else
        echo "Beberapa remote terdeteksi. Silakan pilih satu untuk digunakan:"
        local i=1
        for remote in "${remotes[@]}"; do echo "$i. $remote"; ((i++)); done
        read -p "Pilih nomor remote [1-${#remotes[@]}]: " remote_num
        if ! [[ "$remote_num" =~ ^[0-9]+$ ]] || [ "$remote_num" -lt 1 ] || [ "$remote_num" -gt "${#remotes[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid! Setup gagal.${NC}"; return 1
        fi
        rclone_remote="${remotes[$((remote_num-1))]}"
    fi
    echo -e "Menggunakan remote: ${YELLOW}$rclone_remote${NC}"
    read -p "Masukkan nama FOLDER untuk backup di remote '$rclone_remote' (contoh: xray_backup): " rclone_path
    if [ -z "$rclone_path" ]; then echo -e "${RED}Nama folder tidak boleh kosong! Pengaturan backup gagal.${NC}"; return 1; fi
    echo "RCLONE_REMOTE=$rclone_remote" > "$RCLONE_CONF"
    echo "RCLONE_PATH=$rclone_path" >> "$RCLONE_CONF"
    echo -e "${GREEN}Konfigurasi backup untuk skrip ini berhasil disimpan!${NC}"
    sleep 2
    return 0
}

configure_sysctl() {
    echo "=> Menambahkan konfigurasi sysctl..."
    cat << EOF >> /etc/sysctl.conf
fs.file-max = 500000
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.ip_local_port_range = 10000 65000
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mem = 25600 51200 102400
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.core.rmem_max = 4000000
net.ipv4.tcp_mtu_probing = 1
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
}

# Fungsi untuk instalasi dan konfigurasi WGCF (Cloudflare WARP)
# Catatan: Fungsi ini sekarang hanya akan MENYIAPKAN WGCF, tidak otomatis MENGAKTIFKANNYA
# Aktivasi akan dilakukan secara manual dari menu manajemen WGCF
install_wgcf() {
    clear
    echo -e "${GREEN}==================[ INSTALASI & KONFIGURASI WGCF ]==================${NC}"
    echo "Memasang dependensi..."
    apt-get update -y
    apt-get install -y wireguard-tools openresolv

    if ! command -v wgcf &> /dev/null; then
        echo "Mengunduh dan menginstal wgcf binary terbaru..."
        WGCF_LATEST_URL=$(curl -s "https://api.github.com/repos/ViRb3/wgcf/releases/latest" | grep "browser_download_url" | grep "linux_amd64" | cut -d '"' -f 4)
        if [ -z "$WGCF_LATEST_URL" ]; then
            echo -e "${RED}Gagal mendapatkan URL unduhan wgcf terbaru. Coba lagi nanti atau periksa koneksi internet.${NC}"; return 1
        fi
        if ! wget "$WGCF_LATEST_URL" -O /usr/local/bin/wgcf; then
            echo -e "${RED}Gagal mengunduh wgcf binary!${NC}"; return 1
        fi
        chmod +x /usr/local/bin/wgcf
    fi

    echo "Membuat akun WGCF..."
    # Hapus file toml yang mungkin ada dari percobaan sebelumnya
    rm -f wgcf-account.toml
    if ! wgcf register --accept-tos; then
        echo -e "${RED}Gagal mendaftar akun WGCF. Pastikan koneksi internet stabil.${NC}"; return 1
    fi

    echo "Membuat profil WireGuard..."
    # Hapus file conf yang mungkin ada dari percobaan sebelumnya
    rm -f wgcf-profile.conf
    if ! wgcf generate; then
        echo -e "${RED}Gagal membuat profil WireGuard.${NC}"; return 1
    fi

    echo "Memindahkan dan memodifikasi konfigurasi ke /etc/wireguard/"
    mkdir -p /etc/wireguard
    mv wgcf-profile.conf "$WGCF_CONFIG_FILE" # Menggunakan nama file yang benar: wgcf.conf
    mv wgcf-account.toml /etc/wireguard/ # Simpan account file juga

    # MODIFIKASI FILE WGCF.CONF OTOMATIS
    echo "Memodifikasi $WGCF_CONFIG_FILE untuk kompatibilitas VPS dan IPv6 dinonaktifkan..."
    # Gunakan sed yang lebih tangguh seperti skrip Marzban untuk menghapus IPv6
    sed -i -E 's/, [0-9a-f:]+\/128//; s/, ::\/0//' "$WGCF_CONFIG_FILE" # Hapus AllowedIPs IPv6
    sed -i '/Address = .*:/d' "$WGCF_CONFIG_FILE"                     # Hapus baris Address IPv6 jika ada
    sed -i '/MTU =/d' "$WGCF_CONFIG_FILE"                             # Hapus baris MTU

    # Tambahkan DNS ke konfigurasi WGCF jika belum ada
    if ! grep -q "DNS =" "$WGCF_CONFIG_FILE"; then
        sed -i '/^\[Interface\]/aDNS = 1.1.1.1,1.0.0.1' "$WGCF_CONFIG_FILE"
    fi

    echo "Mengaktifkan layanan WireGuard untuk boot (systemctl enable), tetapi tidak akan memulainya sekarang."
    systemctl enable wg-quick@wgcf

    echo -e "${GREEN}WGCF telah disiapkan. Anda dapat mengaktifkannya dari menu manajemen WGCF.${NC}"
    echo -e "${YELLOW}Konfigurasi Xray akan diperbarui saat WGCF diaktifkan dari menu.${NC}"

    sleep 3
    return 0
}

# Fungsi untuk mengaktifkan/menonaktifkan WGCF
manage_wgcf() {
    clear
    echo -e "${GREEN}===================[ MANAJEMEN WGCF ]===================${NC}"
    echo "1. Aktifkan WGCF (Jalankan traffic Xray melalui WARP)"
    echo "2. Nonaktifkan WGCF (Jalankan traffic Xray langsung)"
    echo "3. Cek Status WGCF"
    echo "4. Kembali"
    echo ""
    read -p "Pilih opsi [1-4]: " choice
    case $choice in
        1)
            if [ ! -f "$WGCF_CONFIG_FILE" ]; then
                echo -e "${RED}File konfigurasi WGCF ($WGCF_CONFIG_FILE) tidak ditemukan. Harap instal WGCF terlebih dahulu.${NC}"
                sleep 2; return
            fi
            echo "Mengaktifkan WGCF..."
            # Pastikan resolv.conf bisa ditulis sementara jika di-chattr +i
            chattr -i /etc/resolv.conf 2>/dev/null || true
            if systemctl start wg-quick@wgcf; then
                echo -e "${GREEN}WGCF berhasil diaktifkan.${NC}"
                regenerate_config
                echo -e "${GREEN}Konfigurasi Xray telah diperbarui.${NC}"
            else
                echo -e "${RED}Gagal mengaktifkan WGCF. Periksa log: systemctl status wg-quick@wgcf.service${NC}"
            fi
            # Kembalikan atribut immutable
            chattr +i /etc/resolv.conf 2>/dev/null || true
            ;;
        2)
            echo "Menonaktifkan WGCF..."
            if systemctl stop wg-quick@wgcf; then
                echo -e "${GREEN}WGCF berhasil dinonaktifkan.${NC}"
                regenerate_config
                echo -e "${GREEN}Konfigurasi Xray telah diperbarui.${NC}"
            else
                echo -e "${RED}Gagal menonaktifkan WGCF.${NC}"
            fi
            ;;
        3)
            echo "Status WGCF:"
            systemctl status wg-quick@wgcf --no-pager
            wg
            ;;
        4) return;;
        *) echo -e "${RED}Pilihan salah!${NC}";;
    esac
    read -n 1 -s -r -p "Tekan tombol apa saja untuk melanjutkan..."
}