#!/bin/bash

#================================================================================================
# FILE KONFIGURASI BERSAMA (Versi dengan XRay Fallbacks & WARP Alternatif)
#================================================================================================

# --- Variabel Global & Warna ---
GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[0;33m"
NC="\033[0m"

# --- Path Direktori & File ---
# Menentukan path absolut dari direktori skrip saat ini
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Path untuk file-file penting
USER_DB="/etc/xray/user_database.txt"
CONFIG_FILE="/usr/local/etc/xray/config.json"
NGINX_CONF="/etc/nginx/conf.d/xray.conf"
CERT_FILE="/etc/xray/xray.crt"
KEY_FILE="/etc/xray/xray.key"
DOMAIN_FILE="/etc/xray/domain.txt"
RCLONE_CONF="/etc/xray/rclone.conf"
WGCF_CONFIG_FILE="/etc/wireguard/wgcf.conf" # Nama file konfigurasi WGCF yang benar

# Path instalasi skrip di sistem
INSTALL_DIR="/usr/local/bin/trojan-manager"
MAIN_SCRIPT_PATH="${INSTALL_DIR}/main.sh"

# --- STATUS GLOBAL UNTUK WARP ---
# Digunakan untuk menentukan jenis WARP yang aktif
WARP_MODE="none" # Bisa 'wgcf', 'warp-cli', atau 'none'

# Fungsi untuk memeriksa hak akses root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}Skrip ini harus dijalankan sebagai root${NC}"
        exit 1
    fi
}

# Fungsi untuk membuat ulang file konfigurasi Xray dan Nginx
regenerate_config() {
    local domain
    domain=$(cat "$DOMAIN_FILE")
    local clients_json=""
    if [ -s "$USER_DB" ]; then
        while IFS= read -r line; do
            local password
            password=$(echo "$line" | cut -d'|' -f1)
            clients_json+="{ \"password\": \"$password\" },"
        done < "$USER_DB"
        clients_json=${clients_json%,}
    fi

    # === KONFIGURASI XRAY BARU DENGAN FALLBACKS ===
    # XRay akan berjalan di port 443 dan menangani TLS.
    local outbound_warp_settings=""
    local routing_warp_settings=""

    if systemctl is-active --quiet wg-quick@wgcf; then # WARP via WGCF Kernel
        WARP_MODE="wgcf"
        outbound_warp_settings=',{ "protocol": "freedom", "tag": "direct", "settings": {} },{ "protocol": "socks", "tag": "warp", "settings": { "servers": [ { "address": "127.0.0.1", "port": 40000 } ] } }'
        routing_warp_settings=',{ "type": "field", "outboundTag": "warp", "ip": ["geoip:private", "geoip:cn", "geoip:kp"] }'
    elif systemctl is-active --quiet warp-svc; then # WARP via warp-cli Userspace
        WARP_MODE="warp-cli"
        outbound_warp_settings=',{ "protocol": "freedom", "tag": "direct", "settings": {} },{ "protocol": "socks", "tag": "warp_proxy", "settings": { "servers": [ { "address": "127.0.0.1", "port": 40000 } ] } }' # Port default warp-cli socks proxy
        routing_warp_settings=',{ "type": "field", "outboundTag": "warp_proxy", "ip": ["geoip:private", "geoip:cn", "geoip:kp"] }'
    else # Tanpa WARP
        WARP_MODE="none"
        outbound_warp_settings=',{ "protocol": "freedom", "tag": "direct", "settings": {} }'
    fi

    cat << EOF > "$CONFIG_FILE"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "trojan",
      "settings": {
        "clients": [ $clients_json ],
        "fallbacks": [
          {
            "dest": 8080,
            "xver": 1
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {
          "certificates": [
            {
              "certificateFile": "$CERT_FILE",
              "keyFile": "$KEY_FILE"
            }
          ]
        },
        "wsSettings": {
          "path": "/trojan-ws"
        }
      }
    }
  ],
  "outbounds": [{ "protocol": "freedom" } $outbound_warp_settings],
  "routing": {
    "domainStrategy": "AsIs",
    "rules": [
      {
        "type": "field",
        "ip": ["geoip:private"],
        "outboundTag": "direct"
      }
      $routing_warp_settings
    ]
  }
}
EOF

    chown -R nobody:nogroup /etc/xray/

    if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
        echo "Me-restart layanan Xray dan Nginx..."
        systemctl restart xray
        systemctl restart nginx
    else
        echo -e "${YELLOW}Sertifikat SSL belum tersedia. Nginx tidak direstart.${NC}"
    fi
}

setup_rclone() {
    if [ -f "$RCLONE_CONF" ]; then return 0; fi
    clear
	echo -e "${YELLOW}===========[ PENGATURAN AWAL BACKUP/RESTORE (RCLONE) ]===========${NC}"
	echo ""
    echo "Anda akan diarahkan ke setup interaktif Rclone untuk menghubungkan akun cloud."
    read -n 1 -s -r -p "Tekan tombol apa saja untuk memulai 'rclone config'..."
    rclone config
    echo -e "\n${GREEN}Setup interaktif Rclone Selesai.${NC}"
	echo -e "${YELLOW}=================================================================${NC}"
	echo ""
    echo "Mendeteksi remote yang tersedia..."
    mapfile -t remotes < <(rclone listremotes | sed 's/://')
    local rclone_remote=""
    if [ ${#remotes[@]} -eq 0 ]; then
        echo -e "${RED}Tidak ada remote Rclone yang terdeteksi. Setup gagal.${NC}"
        return 1
    elif [ ${#remotes[@]} -eq 1 ]; then
        rclone_remote="${remotes[0]}"
        echo -e "${GREEN}Satu remote terdeteksi: ${YELLOW}$rclone_remote${GREEN}. Remote ini akan digunakan secara otomatis.${NC}"
    else
        echo "Beberapa remote terdeteksi. Silakan pilih satu untuk digunakan:"
        local i=1
        for remote in "${remotes[@]}"; do echo "$i. $remote"; ((i++)); done
        read -p "Pilih nomor remote [1-${#remotes[@]}]: " remote_num
        if ! [[ "$remote_num" =~ ^[0-9]+$ ]] || [ "$remote_num" -lt 1 ] || [ "$remote_num" -gt "${#remotes[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid! Setup gagal.${NC}"; return 1
        fi
        rclone_remote="${remotes[$((remote_num-1))]}"
    fi
    echo -e "Menggunakan remote: ${YELLOW}$rclone_remote${NC}"
    read -p "Masukkan nama FOLDER untuk backup di remote '$rclone_remote' (contoh: xray_backup): " rclone_path
    if [ -z "$rclone_path" ]; then echo -e "${RED}Nama folder tidak boleh kosong! Pengaturan backup gagal.${NC}"; return 1; fi
    echo "RCLONE_REMOTE=$rclone_remote" > "$RCLONE_CONF"
    echo "RCLONE_PATH=$rclone_path" >> "$RCLONE_CONF"
    echo -e "${GREEN}Konfigurasi backup untuk skrip ini berhasil disimpan!${NC}"
    sleep 2
    return 0
}

configure_sysctl() {
    echo "=> Menambahkan konfigurasi sysctl..."
    cat << EOF >> /etc/sysctl.conf
fs.file-max = 500000
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.ip_local_port_range = 10000 65000
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mem = 25600 51200 102400
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.core.rmem_max = 4000000
net.ipv4.tcp_mtu_probing = 1
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
}

# Fungsi untuk instalasi dan konfigurasi WGCF (Cloudflare WARP)
# Akan mencoba menginstal WGCF kernel. Jika gagal, akan mencoba warp-cli.
install_wgcf() {
    clear
    echo -e "${GREEN}==================[ INSTALASI & KONFIGURASI CLOUDFLARE WARP ]==================${NC}"
    echo "Mencoba menginstal WGCF (WireGuard kernel mode) terlebih dahulu..."

    # Test kemampuan kernel untuk WireGuard
    local kernel_wg_ok=false
    echo "Memeriksa kemampuan WireGuard kernel..."
    apt-get install -y wireguard-tools openresolv >/dev/null 2>&1
    modprobe wireguard >/dev/null 2>&1
    if ! ip link add dummy0 type wireguard >/dev/null 2>&1; then
        echo -e "${YELLOW}Deteksi: Lingkungan VPS ini mungkin tidak mendukung WireGuard berbasis kernel secara penuh.${NC}"
        echo -e "${YELLOW}Error: 'ip link add' gagal atau modul WireGuard tidak berfungsi dengan baik.${NC}"
        ip link delete dummy0 >/dev/null 2>&1 # Bersihkan dummy device jika sempat dibuat
    else
        echo -e "${GREEN}Deteksi: WireGuard berbasis kernel didukung.${NC}"
        kernel_wg_ok=true
        ip link delete dummy0 >/dev/null 2>&1 # Bersihkan dummy device
    fi
    
    if [ "$kernel_wg_ok" = true ]; then
        echo "Melanjutkan dengan instalasi WGCF (mode kernel)..."
        
        if ! command -v wgcf &> /dev/null; then
            echo "Mengunduh dan menginstal wgcf binary terbaru..."
            WGCF_LATEST_URL=$(curl -s "https://api.github.com/repos/ViRb3/wgcf/releases/latest" | grep "browser_download_url" | grep "linux_amd64" | cut -d '"' -f 4)
            if [ -z "$WGCF_LATEST_URL" ]; then
                echo -e "${RED}Gagal mendapatkan URL unduhan wgcf terbaru. Coba lagi nanti atau periksa koneksi internet.${NC}"; return 1
            fi
            if ! wget "$WGCF_LATEST_URL" -O /usr/local/bin/wgcf; then
                echo -e "${RED}Gagal mengunduh wgcf binary!${NC}"; return 1
            fi
            chmod +x /usr/local/bin/wgcf
        fi

        echo "Membuat akun WGCF..."
        rm -f wgcf-account.toml # Bersihkan file toml lama
        if ! wgcf register --accept-tos; then
            echo -e "${RED}Gagal mendaftar akun WGCF. Pastikan koneksi internet stabil.${NC}"; return 1
        fi

        echo "Membuat profil WireGuard..."
        rm -f wgcf-profile.conf # Bersihkan file conf lama
        if ! wgcf generate; then
            echo -e "${RED}Gagal membuat profil WireGuard.${NC}"; return 1
        fi

        echo "Memindahkan dan memodifikasi konfigurasi ke /etc/wireguard/"
        mkdir -p /etc/wireguard
        mv wgcf-profile.conf "$WGCF_CONFIG_FILE" # Menggunakan nama file yang benar: wgcf.conf
        mv wgcf-account.toml /etc/wireguard/ # Simpan account file juga

        # MODIFIKASI FILE WGCF.CONF OTOMATIS
        echo "Memodifikasi $WGCF_CONFIG_FILE untuk kompatibilitas VPS dan IPv6 dinonaktifkan..."
        sed -i -E 's/, [0-9a-f:]+\/128//; s/, ::\/0//' "$WGCF_CONFIG_FILE" # Hapus AllowedIPs IPv6
        sed -i '/Address = .*:/d' "$WGCF_CONFIG_FILE"                     # Hapus baris Address IPv6 jika ada
        sed -i '/MTU =/d' "$WGCF_CONFIG_FILE"                             # Hapus baris MTU

        # Tambahkan DNS ke konfigurasi WGCF jika belum ada
        if ! grep -q "DNS =" "$WGCF_CONFIG_FILE"; then
            sed -i '/^\[Interface\]/aDNS = 1.1.1.1,1.0.0.1' "$WGCF_CONFIG_FILE"
        fi

        echo "Mengaktifkan layanan WireGuard untuk boot (systemctl enable)..."
        systemctl enable wg-quick@wgcf

        echo "Mencoba mengaktifkan WGCF sekarang..."
        # Pastikan resolv.conf bisa ditulis sementara jika di-chattr +i sebelum start
        chattr -i /etc/resolv.conf 2>/dev/null || true
        if systemctl start wg-quick@wgcf; then
            echo -e "${GREEN}WGCF (mode kernel) berhasil diaktifkan secara otomatis!${NC}"
            WARP_MODE="wgcf"
        else
            echo -e "${RED}Gagal mengaktifkan WGCF (mode kernel) secara otomatis.${NC}"
            echo -e "${YELLOW}Ini mungkin karena keterbatasan VPS Anda. Mencoba alternatif: Cloudflare warp-cli (userspace mode)...${NC}"
            WARP_MODE="none" # Reset untuk mencoba alternatif
            # Lanjutkan ke instalasi warp-cli jika WGCF gagal
            install_warp_cli
        fi
        # Kembalikan atribut immutable resolv.conf
        chattr +i /etc/resolv.conf 2>/dev/null || true

    else # Jika kernel_wg_ok = false
        echo -e "${YELLOW}Lingkungan VPS tidak mendukung WireGuard berbasis kernel. Mencoba alternatif: Cloudflare warp-cli (userspace mode)...${NC}"
        install_warp_cli
    fi
    
    # Perbarui konfigurasi Xray setelah semua upaya WARP
    regenerate_config
    systemctl restart xray # Pastikan Xray me-load konfigurasi baru
    sleep 3
    return 0
}

# Fungsi untuk instalasi dan konfigurasi warp-cli (userspace mode)
install_warp_cli() {
    echo -e "${GREEN}--- Memulai Instalasi Cloudflare warp-cli (Userspace) ---${NC}"
    # Hapus instalasi warp-cli sebelumnya untuk memastikan bersih
    systemctl disable warp-svc >/dev/null 2>&1
    systemctl stop warp-svc >/dev/null 2>&1
    apt-get remove -y cloudflare-warp >/dev/null 2>&1
    rm -f /usr/local/bin/warp-cli >/dev/null 2>&1

    echo "Menambahkan repositori Cloudflare APT..."
    curl -fsSL https://pkg.cloudflareclient.com/pubkey.gpg | gpg --dearmor -o /usr/share/keyrings/cloudflare-warp-archive-keyring.gpg
    echo "deb [signed-by=/usr/share/keyrings/cloudflare-warp-archive-keyring.gpg] https://pkg.cloudflareclient.com/ $(lsb_release -cs) main" | tee /etc/apt/sources.list.d/cloudflare-client.list > /dev/null
    apt-get update -y

    echo "Memasang cloudflare-warp..."
    if ! apt-get install -y cloudflare-warp; then
        echo -e "${RED}Gagal menginstal cloudflare-warp. Fitur WARP tidak tersedia.${NC}"; return 1
    fi

    echo "Mendaftarkan perangkat WARP..."
    warp-cli --accept-tos register

    echo "Mengaktifkan WARP dan mode proxy SOCKS5..."
    warp-cli set-mode proxy
    warp-cli connect

    # Verifikasi status warp-cli
    local check_warp_cli_status_count=0
    local warp_cli_active=false
    while [ "$check_warp_cli_status_count" -lt 5 ]; do
        if warp-cli status | grep -q "Status: Connected"; then
            echo -e "${GREEN}Cloudflare warp-cli berhasil diaktifkan dan terhubung!${NC}"
            warp_cli_active=true
            WARP_MODE="warp-cli"
            break
        fi
        echo "Menunggu warp-cli terhubung... (${check_warp_cli_status_count}/5)"
        sleep 5
        check_warp_cli_status_count=$((check_warp_cli_status_count+1))
    done

    if [ "$warp_cli_active" = false ]; then
        echo -e "${RED}Gagal mengaktifkan Cloudflare warp-cli sepenuhnya. Fitur WARP tidak tersedia.${NC}"
        WARP_MODE="none"
    fi
    return 0
}

# Fungsi untuk mengaktifkan/menonaktifkan WARP (baik WGCF atau warp-cli)
manage_wgcf() { # Nama fungsi di menu utama tetap 'manage_wgcf' untuk kompatibilitas
    clear
    echo -e "${GREEN}===================[ MANAJEMEN CLOUDFLARE WARP ]===================${NC}"
    echo "Current WARP mode: ${YELLOW}${WARP_MODE}${NC}"
    echo "1. Aktifkan WARP (Jalankan traffic Xray melalui WARP)"
    echo "2. Nonaktifkan WARP (Jalankan traffic Xray langsung)"
    echo "3. Cek Status WARP"
    echo "4. Kembali"
    echo ""
    read -p "Pilih opsi [1-4]: " choice
    case $choice in
        1)
            echo "Mengaktifkan WARP..."
            if [ "$WARP_MODE" == "wgcf" ]; then
                echo "Mencoba mengaktifkan WGCF (kernel mode)..."
                chattr -i /etc/resolv.conf 2>/dev/null || true # Sementara non-immutable
                if systemctl start wg-quick@wgcf; then
                    echo -e "${GREEN}WGCF berhasil diaktifkan.${NC}"
                else
                    echo -e "${RED}Gagal mengaktifkan WGCF. Tetap tanpa WARP.${NC}"
                    systemctl stop wg-quick@wgcf >/dev/null 2>&1 # Pastikan mati
                fi
                chattr +i /etc/resolv.conf 2>/dev/null || true # Kembalikan immutable
            elif [ "$WARP_MODE" == "warp-cli" ]; then
                echo "Mencoba mengaktifkan warp-cli (userspace mode)..."
                warp-cli connect
                if warp-cli status | grep -q "Status: Connected"; then
                    echo -e "${GREEN}warp-cli berhasil diaktifkan.${NC}"
                else
                    echo -e "${RED}Gagal mengaktifkan warp-cli. Tetap tanpa WARP.${NC}"
                    warp-cli disconnect >/dev/null 2>&1
                fi
            else
                echo -e "${YELLOW}WARP belum diinstal atau tidak aktif. Mencoba menginstal WGCF (mode kernel) kembali...${NC}"
                install_wgcf # Akan mencoba instal ulang/aktifkan yang sesuai
            fi
            regenerate_config # Selalu update konfigurasi Xray
            systemctl restart xray
            ;;
        2)
            echo "Menonaktifkan WARP..."
            if systemctl is-active --quiet wg-quick@wgcf; then
                systemctl stop wg-quick@wgcf
                echo -e "${GREEN}WGCF dinonaktifkan.${NC}"
            elif systemctl is-active --quiet warp-svc; then
                warp-cli disconnect
                echo -e "${GREEN}warp-cli dinonaktifkan.${NC}"
            fi
            WARP_MODE="none" # Set mode ke none
            regenerate_config # Update konfigurasi Xray tanpa WARP
            systemctl restart xray
            ;;
        3)
            echo "Status WARP:"
            local current_status="Tidak Aktif"
            if systemctl is-active --quiet wg-quick@wgcf; then
                current_status="${GREEN}WGCF (Kernel Mode) Aktif${NC}"
                wg
            elif systemctl is-active --quiet warp-svc; then
                current_status="${GREEN}warp-cli (Userspace Mode) Aktif${NC}"
                warp-cli status
            fi
            echo -e "Status Keseluruhan: $current_status"
            ;;
        4) return;;
        *) echo -e "${RED}Pilihan salah!${NC}";;
    esac
    read -n 1 -s -r -p "Tekan tombol apa saja untuk melanjutkan..."
}