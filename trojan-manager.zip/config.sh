#!/bin/bash

#================================================================================================
# FILE KONFIGURASI BERSAMA (Versi dengan Deteksi Remote Rclone Otomatis)
#================================================================================================

# --- Variabel Global & Warna ---
GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[0;33m"
NC="\033[0m"

# --- Path Direktori & File ---
# Menentukan path absolut dari direktori skrip saat ini
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Path untuk file-file penting
USER_DB="/etc/xray/user_database.txt"
CONFIG_FILE="/usr/local/etc/xray/config.json"
NGINX_CONF="/etc/nginx/conf.d/xray.conf"
CERT_FILE="/etc/xray/xray.crt"
KEY_FILE="/etc/xray/xray.key"
DOMAIN_FILE="/etc/xray/domain.txt"
RCLONE_CONF="/etc/xray/rclone.conf"

# Path instalasi skrip di sistem
INSTALL_DIR="/usr/local/bin/trojan-manager"
MAIN_SCRIPT_PATH="${INSTALL_DIR}/main.sh"


# --- Fungsi Bersama ---

# Fungsi untuk memeriksa hak akses root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}Skrip ini harus dijalankan sebagai root${NC}"
        exit 1
    fi
}

# Fungsi untuk membuat ulang file konfigurasi Xray dan Nginx
regenerate_config() {
    local domain
    domain=$(cat "$DOMAIN_FILE")
    local clients_json=""
    if [ -s "$USER_DB" ]; then
        while IFS= read -r line; do
            local password
            password=$(echo "$line" | cut -d'|' -f1)
            clients_json+="{ \"password\": \"$password\" },"
        done < "$USER_DB"
        clients_json=${clients_json%,}
    fi

    # Buat config xray
    cat << EOF > "$CONFIG_FILE"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "listen": "127.0.0.1",
      "port": 10002,
      "protocol": "trojan",
      "settings": { "clients": [ $clients_json ] },
      "streamSettings": { "network": "ws", "security": "none", "wsSettings": { "path": "/trojan-ws" } }
    }
  ],
  "outbounds": [{ "protocol": "freedom" }]
}
EOF

    # Buat config nginx
    cat << EOF > "$NGINX_CONF"
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $domain;
    ssl_certificate $CERT_FILE;
    ssl_certificate_key $KEY_FILE;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384";
    location /trojan-ws {
        if (\$http_upgrade != "websocket") {
            return 404;
        }
        proxy_pass http://127.0.0.1:10002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
}
EOF

    chown -R www-data:www-data /etc/xray/

    if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
        echo "Me-restart layanan Xray dan Nginx..."
        systemctl restart xray
        systemctl restart nginx
    else
        echo -e "${YELLOW}Sertifikat SSL belum tersedia. Nginx tidak direstart.${NC}"
    fi
}

# --- FUNGSI YANG DIMODIFIKASI ---
setup_rclone() {
    # Jika file konfigurasi sudah ada, tidak perlu melakukan apa-apa.
    if [ -f "$RCLONE_CONF" ]; then
        return 0
    fi

    # Proses setup untuk pertama kali.
    clear
    echo -e "${YELLOW}--- Pengaturan Awal Backup (Rclone) ---${NC}"
    echo "Anda akan diarahkan ke setup interaktif Rclone untuk menghubungkan akun cloud."
    read -n 1 -s -r -p "Tekan tombol apa saja untuk memulai 'rclone config'..."
    
    # Menjalankan setup interaktif rclone
    rclone config

    echo ""
    echo -e "${GREEN}Setup interaktif Rclone Selesai.${NC}"
    echo "------------------------------------------------------------"
    echo "Mendeteksi remote yang tersedia..."
    
    # Membaca daftar remote yang ada ke dalam sebuah array
    mapfile -t remotes < <(rclone listremotes | sed 's/://')

    local rclone_remote=""

    # KASUS 1: Tidak ada remote yang dibuat
    if [ ${#remotes[@]} -eq 0 ]; then
        echo -e "${RED}Tidak ada remote Rclone yang terdeteksi. Setup gagal.${NC}"
        echo -e "${YELLOW}Pastikan Anda menyelesaikan 'rclone config' dengan benar.${NC}"
        return 1
    # KASUS 2: Hanya ada satu remote, langsung pilih otomatis
    elif [ ${#remotes[@]} -eq 1 ]; then
        rclone_remote="${remotes[0]}"
        echo -e "${GREEN}Satu remote terdeteksi: ${YELLOW}$rclone_remote${GREEN}. Remote ini akan digunakan secara otomatis.${NC}"
    # KASUS 3: Ada beberapa remote, minta pengguna memilih
    else
        echo "Beberapa remote terdeteksi. Silakan pilih satu untuk digunakan:"
        local i=1
        for remote in "${remotes[@]}"; do
            echo "$i. $remote"
            ((i++))
        done
        read -p "Pilih nomor remote [1-${#remotes[@]}]: " remote_num
        if ! [[ "$remote_num" =~ ^[0-9]+$ ]] || [ "$remote_num" -lt 1 ] || [ "$remote_num" -gt "${#remotes[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid! Setup gagal.${NC}"
            return 1
        fi
        rclone_remote="${remotes[$((remote_num-1))]}"
    fi
    
    echo -e "Menggunakan remote: ${YELLOW}$rclone_remote${NC}"
    echo ""
    read -p "Masukkan nama FOLDER untuk backup di remote '$rclone_remote' (contoh: xray_backup): " rclone_path

    if [ -z "$rclone_path" ]; then
        echo -e "${RED}Nama folder tidak boleh kosong! Pengaturan backup gagal.${NC}"
        return 1
    fi

    # Menyimpan pengaturan
    echo "RCLONE_REMOTE=$rclone_remote" > "$RCLONE_CONF"
    echo "RCLONE_PATH=$rclone_path" >> "$RCLONE_CONF"
    
    echo -e "${GREEN}Konfigurasi backup untuk skrip ini berhasil disimpan!${NC}"
    sleep 2
    return 0
}